import {Component} from '@angular/core'

@Component({
    selector: 'app-home-page',
    templateUrl: 'app/components/home/home.html'
})
export class HomeComponent{
    
}