import {bootstrap} from '@angular/platform-browser-dynamic';
import {ROUTER_PROVIDERS} from '@angular/router';
import {AppComponent} from './components/application/app.component'

bootstrap(AppComponent, [
    ROUTER_PROVIDERS
]);